// AnimTube Bridge v1.3.5 - Hybrid (ChatGPT + Gemini) - AUTO VERSION
let isRunningGrokCycle = false;
let lastGrokExitTime = 0; // Guard for double back-navigation
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "TO_CHATGPT") {
        executeScriptCycle(request.prefix);
    } else if (request.type === "TO_GEMINI") {
        executeLiteralCycle(request.prompt, request.assets, request.assetIds);
    } else if (request.type === "ANIMTUBE_CMD_SCRIPT") {
        executeScriptCycle(request.prefix);
    } else if (request.type === "ANIMTUBE_CMD_SPLIT") {
        executeSplitCycle(request.script, request.prefix);
    } else if (request.type === "ANIMTUBE_STATUS") {
        relayToStudio(request);
    } else if (request.type === "TO_GROK") {
        executeGrokCycle(request.prompt, request.assets, request.assetIds);
    } else if (request.type === "FROM_GEMINI") {
        relayToStudio(request);
        setTimeout(() => {
            focusStudio();
            setTimeout(() => relayToStudio({ type: "ANIMTUBE_CMD_PASTE_AUTO" }), 3000);
        }, 3000); 
    } else if (request.type === "FROM_CHATGPT") {
        relayToStudio(request);
    }
    return true;
});

async function executeSplitCycle(scriptText, customPrefix) {
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const report = (text) => chrome.runtime.sendMessage({ type: "ANIMTUBE_STATUS", text: text });

    report("🤖 РОБОТ: Запуск разделения сценария на промпты (Gemini)...");

    const tabs = await chrome.tabs.query({});
    const geminiTab = tabs.find(t => t.url && t.url.includes("gemini.google.com"));

    if (!geminiTab) {
        report("❌ Gemini не открыт. Откройте его и попробуйте снова.");
        return;
    }

    chrome.tabs.update(geminiTab.id, { active: true });
    await sleep(1500);

    report("⌨️ Ввод сценария и инструкции по разделению...");
    await chrome.scripting.executeScript({
        target: { tabId: geminiTab.id },
        func: (text, prefix) => {
            const editor = document.querySelector(".ql-editor") || document.querySelector("input") || document.querySelector("textarea");
            if (editor) {
                const finalInstruction = (prefix && prefix.trim()) ? prefix : "Please split this script into a chronological list of detailed image prompts for an animation. Format each line as 'Prompt N: [Description]'.";
                const prompt = finalInstruction + "\n\n" + text;
                
                if (editor.tagName === "DIV") editor.innerHTML = "<p>" + prompt.replace(/\n/g, '<br>') + "</p>";
                else editor.value = prompt;
                
                setTimeout(() => {
                    const sendBtn = document.querySelector('button[aria-label*="Send"], .send-button, [data-test-id="send-button"]');
                    if (sendBtn) sendBtn.click();
                }, 500);
            }
        },
        args: [scriptText, customPrefix]
    });

    const waitTime = 60;
    for (let i = waitTime; i >= 0; i--) {
        report(`⌛ Gemini создает кадры... (${i}с)`);
        await sleep(1000);
    }

    report("📋 Копирование промптов из Gemini...");
    await chrome.scripting.executeScript({
        target: { tabId: geminiTab.id },
        func: async () => {
            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
            await sleep(1000);
            const copyButtons = document.querySelectorAll('button[aria-label*="Copy"], button[title*="Copy"], .copy-button');
            if (copyButtons.length > 0) {
                const lastCopyBtn = copyButtons[copyButtons.length - 1];
                lastCopyBtn.click();
                return "CLICKED";
            }
            return "NOT_FOUND";
        }
    });

    const captureResult = await chrome.scripting.executeScript({
        target: { tabId: geminiTab.id },
        func: async () => {
            const responses = document.querySelectorAll('.model-response-text, .message-content, .prose, [data-message-author-role="assistant"]');
            if (responses.length > 0) {
                const lastRes = responses[responses.length - 1];
                return lastRes.innerText || lastRes.textContent;
            }
            return "";
        }
    });

    const parsedText = captureResult[0].result;

    if (parsedText) {
        report("✅ Данные захвачены! Возвращаюсь в Студию...");
        await sleep(1500);
        focusStudio();
        await sleep(1000);
        relayToStudio({ type: "FROM_GEMINI_PROMPTS", text: parsedText });
    } else {
        report("❌ Не удалось захватить промпты.");
    }
}

async function executeScriptCycle(prefix) {
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const report = (msg) => relayToStudio({ type: "ANIMTUBE_STATUS", text: msg });

    const tabs = await chrome.tabs.query({});
    const aiTab = tabs.find(t => t.url && (t.url.includes("chatgpt.com") || t.url.includes("chat.openai.com")));
    
    if (!aiTab) {
        report("❌ Ошибка: Вкладка ChatGPT не найдена!");
        return;
    }

    report("🛰️ ПЕРЕКЛЮЧЕНИЕ НА CHATGPT...");
    
    await chrome.windows.update(aiTab.windowId, { focused: true });
    await chrome.tabs.update(aiTab.id, { active: true });
    await sleep(1500); 

    report("✏️ Ввожу запрос для сценария (ChatGPT)...");
    await chrome.scripting.executeScript({
        target: { tabId: aiTab.id },
        func: async (text) => {
            const editor = document.querySelector('#prompt-textarea');
            if (editor) {
                editor.focus();
                editor.value = "";
                document.execCommand('insertText', false, text);
                editor.dispatchEvent(new Event('input', { bubbles: true }));
                await new Promise(r => setTimeout(r, 800));
                const sendBtn = document.querySelector('[data-testid="send-button"]');
                if (sendBtn) sendBtn.click();
            }
        },
        args: [prefix]
    });

    for (let i = 90; i > 0; i--) {
        report(`⏳ Ожидание сценария: ${i} сек...`);
        await sleep(1000);
        if (i % 30 === 0) chrome.tabs.update(aiTab.id, { active: true });
    }

    report("📋 Поиск ответа в ChatGPT...");
    const scriptCapture = await chrome.scripting.executeScript({
        target: { tabId: aiTab.id },
        func: async () => {
            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
            for (let i = 0; i < 3; i++) {
                window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
                await sleep(500);
            }
            const copyBtns = document.querySelectorAll('button[aria-label="Copy"]');
            const responses = document.querySelectorAll('[data-message-author-role="assistant"]');
            let capturedText = "";
            if (responses.length > 0) {
                const lastRes = responses[responses.length - 1];
                capturedText = lastRes.innerText || lastRes.textContent;
            }
            if (copyBtns.length > 0) {
                copyBtns[copyBtns.length - 1].click();
                chrome.runtime.sendMessage({ type: "ANIMTUBE_STATUS", text: "✅ Текст скопирован." });
            } else if (capturedText) {
                await navigator.clipboard.writeText(capturedText.trim());
            }
            return capturedText.trim();
        }
    });

    const fullScriptText = scriptCapture[0].result;
    await sleep(1500);
    focusStudio();
    await sleep(800);

    if (fullScriptText) {
        relayToStudio({ type: "FROM_CHATGPT_SCRIPT", text: fullScriptText });
        report("✅ ЦИКЛ ЗАВЕРШЕН. Сценарий вставлен!");
    } else {
        report("❌ Ошибка: Сценарий не захвачен.");
    }
}

async function executeLiteralCycle(promptText, assets, assetIds) {
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const report = (msg) => relayToStudio({ type: "ANIMTUBE_STATUS", text: msg });

    const tabs = await chrome.tabs.query({});
    const geminiTab = tabs.find(t => t.url && t.url.includes("gemini.google.com"));
    const studioTab = tabs.find(t => t.url && (t.url.includes("localhost") || t.url.includes("127.0.0.1") || t.title.includes("AnimTube")));

    if (!geminiTab) {
        report("❌ Ошибка: Вкладка Gemini не найдена!");
        return;
    }

    if (studioTab) {
        chrome.windows.update(studioTab.windowId, { focused: true });
        chrome.tabs.update(studioTab.id, { active: true });
        report("📋 Студия: Готовлю текст к копированию...");
        relayToStudio({ type: "ANIMTUBE_CMD_VISUAL_COPY", assetIds: assetIds || [] });
        await sleep(3500);
        report("✅ Промт в буфере! Перехожу в Gemini...");
    }

    chrome.windows.update(geminiTab.windowId, { focused: true });
    chrome.tabs.update(geminiTab.id, { active: true });
    await sleep(1500); 
    
    report("✏️ Вставляю текст промта в Gemini...");
    await chrome.scripting.executeScript({
        target: { tabId: geminiTab.id },
        func: (text) => {
            const editor = document.querySelector('div[contenteditable="true"]') || document.querySelector('.ql-editor') || document.querySelector('textarea');
            if (editor) {
                editor.focus();
                document.execCommand('selectAll', false, null);
                document.execCommand('delete', false, null);
                if (editor.tagName === "DIV") editor.innerText = text;
                else editor.value = text;
                ['input', 'change', 'keydown', 'keyup', 'blur'].forEach(t => editor.dispatchEvent(new Event(t, { bubbles: true })));
                if (editor.innerText.length < 5) document.execCommand('insertText', false, text);
            }
        },
        args: [promptText]
    });

    await sleep(3000);

    if (studioTab) {
        chrome.windows.update(studioTab.windowId, { focused: true });
        chrome.tabs.update(studioTab.id, { active: true });
        report(`🔄 Возвращаюсь в Студию для копирования промта...`);
        relayToStudio({ type: "ANIMTUBE_CMD_VISUAL_COPY", assetIds: assetIds || [] }); 
        await sleep(3500);
        report("✅ Промт скопирован. Перехожу в Gemini для вставки...");
    }

    chrome.windows.update(geminiTab.windowId, { focused: true });
    chrome.tabs.update(geminiTab.id, { active: true });
    report("🤔 Возврат в Gemini. Вставка ассетов...");
    await sleep(3000);

    if (assets && assets.length > 0) {
        await chrome.scripting.executeScript({
            target: { tabId: geminiTab.id },
            func: async (imageAssets) => {
                const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                const editor = document.querySelector('div[contenteditable="true"]') || document.querySelector('.ql-editor');
                if (editor) {
                    for (const base64 of imageAssets) {
                        try {
                            const parts = base64.split(';base64,');
                            if (parts.length < 2) continue;
                            const blob = await (await fetch(base64)).blob();
                            const file = new File([blob], "asset.png", { type: blob.type });
                            const dataTransfer = new DataTransfer();
                            dataTransfer.items.add(file);
                            editor.focus();
                            editor.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dataTransfer, bubbles: true }));
                            await sleep(2000);
                        } catch (e) {}
                    }
                }
            },
            args: [assets]
        });
    }

    await sleep(1000);
    await chrome.scripting.executeScript({
        target: { tabId: geminiTab.id },
        func: async () => {
            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
            const sendBtn = document.querySelector('button[aria-label*="Send"]') || document.querySelector('button[aria-label*="Отправить"]');
            if (sendBtn) sendBtn.click();
            await sleep(120000); // Wait for generation (User requested increase to 120s)
            const allImgs = Array.from(document.querySelectorAll('img'));
            const frames = allImgs.filter(img => (img.naturalWidth || img.clientWidth) > 200);
            if (frames.length > 0) {
                const img = frames[frames.length - 1];
                img.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
                await sleep(1800);
                let p = img;
                for (let i = 0; i < 7; i++) { if (p.parentElement) p = p.parentElement; }
                const copyBtn = p.querySelector('button[aria-label*="Copy"], button[aria-label*="Копировать"]');
                if (copyBtn) copyBtn.click();
                const res = await fetch(img.src);
                const blob = await res.blob();
                const reader = new FileReader();
                reader.onloadend = () => chrome.runtime.sendMessage({ type: "FROM_GEMINI", base64: reader.result });
                reader.readAsDataURL(blob);
            }
        }
    });
}

// --- GROK ANIMATION CYCLE (v1.3.1) ---
async function executeGrokCycle(promptText, assets, assetIds) {
    if (isRunningGrokCycle) {
        console.warn("⚠️ Grok Cycle is already running. Ignoring duplicate request.");
        return;
    }
    isRunningGrokCycle = true;
    
    try {
        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
        const report = (msg) => relayToStudio({ type: "ANIMTUBE_STATUS", text: msg });

        report("🚀 Extension: Получена команда TO_GROK. Ищу/Создаю вкладку...");

        const tabs = await chrome.tabs.query({});
        
        let grokTab = tabs.find(t => {
            const hasGrokUrl = t.url && (t.url.includes("grok.com") || t.url.includes("x.com/i/grok"));
            const hasGrokTitle = t.title && t.title.toLowerCase().includes("grok");
            return hasGrokUrl || hasGrokTitle;
        });
        
        const studioTab = tabs.find(t => t.url && (t.url.includes("localhost") || t.url.includes("127.0.0.1") || t.title.includes("AnimTube")));

        if (!grokTab) {
            report("🆕 Вкладка Grok не найдена. Создаю новую... (grok.com/imagine)");
            grokTab = await chrome.tabs.create({ url: "https://grok.com/imagine" });
            report("⏳ Жду 8 сек для инициализации Grok...");
            await sleep(8000);
        } else {
            const currentUrl = grokTab.url || "";
            if (!currentUrl.includes("/imagine")) {
                report("🔄 Переход из чата в режим Генерации... (grok.com/imagine)");
                await chrome.tabs.update(grokTab.id, { url: "https://grok.com/imagine" });
                report("⏳ Жду 8 сек для прогрузки интерфейса Grok...");
                await sleep(8000);
            }
        }
    
        if (!grokTab) {
            report(`❌ Ошибка: Не удалось создать или найти вкладку Grok!`);
            isRunningGrokCycle = false;
            return;
        }

        report("📋 Студия: Готовлю текст промта... (3 сек)");
        await sleep(1000);
        report("📋 Студия: Готовлю текст промта... (2 сек)");
        await sleep(1000);
        report("📋 Студия: Готовлю текст промта... (1 сек)");
        await sleep(1000);

    report(`✅ Переключаюсь в Grok для вставки текста...`);

    // 1. Switch to Grok
    try {
        await chrome.windows.update(grokTab.windowId, { focused: true });
        await chrome.tabs.update(grokTab.id, { active: true });
    } catch (e) {
        report("❌ Ошибка переключения на Grok: " + e.message);
        return;
    }
    await sleep(2000); 
    
    // 2. Paste text in Grok
    report("✏️ Вставляю промт в Grok...");
    await chrome.scripting.executeScript({
        target: { tabId: grokTab.id },
        func: async (text) => {
            const editor = document.querySelector('textarea, div[contenteditable="true"]');
            if (editor) {
                editor.focus();
                
                // 1. Clear natively
                document.execCommand('selectAll', false, null);
                document.execCommand('delete', false, null);
                
                // 2. Insert text natively (Triggers all framework listeners naturally)
                let success = document.execCommand('insertText', false, text);
                
                // 3. Bruteforce fallback
                if (!success || (editor.value === "" && editor.innerText === "")) {
                    if (editor.tagName === "TEXTAREA") {
                        editor.value = text;
                        // React 16+ Hack
                        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
                        if (setter) setter.call(editor, text);
                    } else {
                        editor.innerText = text;
                    }
                }
                
                // 4. Fire standard synthetic events to wake up React
                ['input', 'change', 'keydown', 'keyup'].forEach(e => {
                    editor.dispatchEvent(new Event(e, { bubbles: true }));
                });
            }
        },
        args: [promptText]
    });

    report("⏳ Жду обработки текста в Grok... (2 сек)");
    await sleep(2000);

    // 3. Switch back to Studio
    if (studioTab) {
        report("🔄 Возвращаюсь на сайт Студии...");
        try {
            await chrome.windows.update(studioTab.windowId, { focused: true });
            await chrome.tabs.update(studioTab.id, { active: true });
        } catch (e) {}
        
        await sleep(1000);
        
        // 4. Copy image
        report("📋 Студия: Копирую кадр...");
        relayToStudio({ type: "ANIMTUBE_CMD_VISUAL_COPY", assetIds: assetIds || [] });
        
        report("⏳ Ожидание для буфера обмена... (3)");
        await sleep(1000);
        report("⏳ Ожидание для буфера обмена... (2)");
        await sleep(1000);
        report("⏳ Ожидание для буфера обмена... (1)");
        await sleep(1000);
        report("✅ Кадр скопирован. Возвращаюсь в Grok...");
        await sleep(500);
    }

    // 5. Switch back to Grok
    try {
        await chrome.windows.update(grokTab.windowId, { focused: true });
        await chrome.tabs.update(grokTab.id, { active: true });
    } catch (e) {}
    
    report("⏳ Ожидание подготовки Grok... (3)");
    await sleep(1000);
    report("⏳ Ожидание подготовки Grok... (2)");
    await sleep(1000);
    report("⏳ Ожидание подготовки Grok... (1)");
    await sleep(1000);

    // 6. Paste Image & Send
    report("🖼️ Вставляю кадр в Grok...");
    await chrome.scripting.executeScript({
        target: { tabId: grokTab.id },
        func: async (imageAssets) => {
            const report = (msg) => chrome.runtime.sendMessage({ type: "ANIMTUBE_STATUS", text: msg });
            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
            
            const editor = document.querySelector('textarea') || document.querySelector('div[contenteditable="true"]');
            
            if (editor) {
                editor.focus();
                
                if (imageAssets && imageAssets.length > 0) {
                    try {
                        const base64 = imageAssets[0];
                        const parts = base64.split(';base64,');
                        if (parts.length >= 2) {
                            const contentType = parts[0].split(':')[1];
                            const byteCharacters = atob(parts[1]);
                            const byteArrays = [];
                            for (let offset = 0; offset < byteCharacters.length; offset += 512) {
                                const slice = byteCharacters.slice(offset, offset + 512);
                                const byteNumbers = new Array(slice.length);
                                for (let i = 0; i < slice.length; i++) byteNumbers[i] = slice.charCodeAt(i);
                                byteArrays.push(new Uint8Array(byteNumbers));
                            }
                            const blob = new Blob(byteArrays, { type: contentType });
                            const file = new File([blob], "frame.png", { type: contentType });
                            const dataTransfer = new DataTransfer();
                            dataTransfer.items.add(file);
                            
                            // Method 1: Native paste if OS clipboard is populated
                            document.execCommand('paste');
                            
                            // Method 2: Fallback programmatic paste event
                            editor.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dataTransfer, bubbles: true, cancelable: true }));

                            // Method 3: Direct File Upload to input if accessible
                            const fileInput = document.querySelector('input[type="file"]');
                            if (fileInput) {
                                fileInput.files = dataTransfer.files;
                                fileInput.dispatchEvent(new Event('change', { bubbles: true }));
                            }

                            report("✅ Кадр скопирован! Жду 8 сек перед отправкой для имитации человека...");
                            await sleep(8000); 
                        }
                    } catch (e) { report("⚠️ Ошибка программной вставки кадра: " + e.message); }
                }
                
                // 1. Human-like interaction: Focus and "type" something
                editor.focus();
                await sleep(500);
                document.execCommand('insertText', false, ' '); // Insert space
                await sleep(300);
                document.execCommand('delete'); // Delete space to trigger dirty state
                
                // 2. Fire events to wake up React
                ['input', 'change', 'keydown', 'keyup'].forEach(e => editor.dispatchEvent(new Event(e, { bubbles: true })));
                
                await sleep(1000);

                // 3. Robustly find the Send button
                const allButtons = Array.from(document.querySelectorAll('button'));
                const sendBtn = allButtons.reverse().find(b => {
                    const aria = (b.getAttribute('aria-label') || "").toLowerCase();
                    const hasSvgIcon = b.querySelector('svg:not(.hidden)');
                    const hasNoText = !b.innerText.trim();
                    const isSubmitType = b.getAttribute('type') === 'submit';
                    
                    return aria.includes('grok') || 
                           aria.includes('send') || 
                           aria.includes('отправить') || 
                           isSubmitType || 
                           (hasSvgIcon && hasNoText);
                });

                if (sendBtn) {
                    sendBtn.removeAttribute('disabled');
                    sendBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    await sleep(1200);
                    
                    // --- DOUBLE CLICK ON SEND (Exactly 2 times) ---
                    const clicker = () => sendBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
                    clicker();
                    await sleep(800);
                    clicker();
                    report("✅ Промт отправлен! (нажато РОВНО 2 раза)");
                } else {
                    // Fallback: Enter key
                    editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
                    report("⚠️ Кнопка не найдена, пробую Enter...");
                }
            }
        },
        args: [assets]
    });

    // Wait for generation (Animation takes longer)
    const waitTime = 120;
    for (let i = waitTime; i >= 0; i-=5) {
        if (i > 0) {
            report(`⌛ Grok создает анимацию... (${i}с)`);
            await sleep(5000);
        }
    }

    report("📥 Поиск готовой анимации (ОБЯЗАТЕЛЬНОЕ СКАЧИВАНИЕ)...");
    
    const downloadResult = await chrome.scripting.executeScript({
        target: { tabId: grokTab.id },
        func: async () => {
            const report = (msg) => chrome.runtime.sendMessage({ type: "ANIMTUBE_STATUS", text: msg });
            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
            
            report("🔍 СКАНЕР: Начинаю цикл поиска кнопки Скачать (до 5 попыток)...");
            
            const findDownload = () => {
                // 1. Specific SVG Path for Download (Multiple variants)
                const dAttributeGrok = [
                    "M19 9h-4V3H9v6H5l7 7 7-7z", // Simple Down Arrow
                    "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 11h3l-4 4-4-4h3V9h2v4z", // Circle Down Arrow
                    "M4 16v2h16v-2h-16zm12-9l-1.41-1.41-3.59 3.59v-8.18h-2v8.18l-3.59-3.59-1.41 1.41 6 6 6-6z" // Down arrow with bar
                ];
                
                const allSVGs = Array.from(document.querySelectorAll('svg'));
                for (const svg of allSVGs) {
                    const paths = Array.from(svg.querySelectorAll('path'));
                    if (paths.some(p => dAttributeGrok.some(d => (p.getAttribute('d') || "").includes(d)))) {
                        const btn = svg.closest('button') || svg.closest('a') || svg.closest('[role="button"]');
                        if (btn) return btn;
                    }
                }

                // 2. Search by label/title/text on the right side
                const buttons = Array.from(document.querySelectorAll('button, a, [role="button"]'));
                const rightEdge = window.innerWidth * 0.5;
                
                const candidates = buttons.filter(b => {
                    const label = (b.getAttribute('aria-label') || b.title || b.innerText || "").toLowerCase();
                    const isDownload = label.includes('download') || label.includes('скачать') || label.includes('save') || label.includes('сохранить');
                    const rect = b.getBoundingClientRect();
                    return isDownload && rect.width > 0 && rect.right > rightEdge;
                });
                
                if (candidates.length > 0) return candidates[candidates.length - 1];

                // 3. Last resort: Find buttons next to the video/image
                const media = document.querySelector('video, img[src*="media"]');
                if (media) {
                    let parent = media.parentElement;
                    for(let i=0; i<8; i++) {
                        if(!parent) break;
                        const localBtn = parent.querySelector('button, [role="button"]');
                        if(localBtn && (localBtn.innerText.length < 5 || /download|save/i.test(localBtn.innerText))) return localBtn;
                        parent = parent.parentElement;
                    }
                }

                return null;
            };

            for (let i = 1; i <= 5; i++) {
                const btn = findDownload();
                if (btn) {
                    btn.click();
                    report(`✅ ПОПЫТКА ${i}: Кнопка Скачать НАЙДЕНА И НАЖАТА!`);
                    return true;
                }
                report(`⏳ ПОПЫТКА ${i}: Кнопка пока не появилась, жду 2 сек...`);
                await sleep(2000);
                window.scrollTo(0, document.body.scrollHeight / 2); // Subtle scroll to wake up UI
            }
            
            return false;
        }
    });

    const downloadClicked = downloadResult[0].result;

    if (!downloadClicked) {
        report("❌ КРИТИЧЕСКАЯ ОШИБКА: Кнопка скачивания не найдена после 5 попыток. ВЫХОД ЗАБЛОКИРОВАН.");
        isRunningGrokCycle = false;
        return; // STOP HERE as requested: "ONLY after that he can click back"
    }
    
    // --- MANDATORY EXIT SEQUENCE (ONE ACTION ONLY) ---
    // Guard: Prevent double-navigation within 8 seconds
    if (Date.now() - lastGrokExitTime < 8000) {
        report("⚠️ Пропускаю дублирующий выход (уже выполнено).");
        isRunningGrokCycle = false;
        return;
    }

    report("⌛ Скачивание завершено. Ожидаю 5 сек (сохранение на диск)...");
    await sleep(5000); 

    report("🔄 Возврат на страницу генерации (grok.com/imagine)...");
    try {
        await chrome.tabs.update(grokTab.id, { url: "https://grok.com/imagine" });
        report("✅ Переход выполнен!");
    } catch (e) {
        report("❌ Ошибка навигации: " + e.message);
    }

    report("⌛ Жду 5 сек для очистки Grok...");
    await sleep(5000); 
    
    if (studioTab) {
        try {
            await chrome.windows.update(studioTab.windowId, { focused: true });
            await chrome.tabs.update(studioTab.id, { active: true });
        } catch(e){}
    }
    
    report("🔄 Отправляю сигнал готовности...");
    relayToStudio({ type: "FROM_GROK_DONE" });
    } finally {
        isRunningGrokCycle = false;
    }
}

function relayToStudio(msg) {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            const isStudio = tab.url && (tab.url.includes("localhost") || tab.url.includes("127.0.0.1") || (tab.title && tab.title.includes("AnimTube")));
            if (isStudio) {
                try {
                    chrome.tabs.sendMessage(tab.id, msg).catch(() => {});
                } catch (e) {}
            }
        });
    });
}

function focusStudio() {
    chrome.tabs.query({}, (tabs) => {
        const t = tabs.find(t => t.url && (t.url.includes("localhost") || t.url.includes("127.0.0.1") || (t.title && t.title.includes("AnimTube"))));
        if (t && t.id) { 
            try { chrome.windows.update(t.windowId, { focused: true }).catch(() => {}); } catch(e){}
            try { chrome.tabs.update(t.id, { active: true }).catch(() => {}); } catch(e){}
        }
    });
}
